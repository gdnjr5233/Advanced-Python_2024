# LatexGenerator5233-YOLOer  
## A simple LaTeX table and image generator.

**Installation**  
You can install LatexGenerator5233-YOLOer using pip:  
**pip install latexgenerator5233-yoloer**

**Contributing**  
Contributions are welcome! For major changes, please open an issue first to discuss what you would like to change.  
Please make sure to update tests as appropriate.

**Author**  
Wangquanyu - Initial work - w1450111904@gmail.com  
Feel free to adjust and expand this template to better fit your project!